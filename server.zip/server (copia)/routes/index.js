let express = require('express');
let router = express.Router();
let { exec } = require('child_process');
let fs = require('fs');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/camera', function(req, res, next) {
  exec('python3 python/camera.py', function(error, stdout, stderr) {
    if(error)
      console.log(error)
  });
  res.send('Avvio della fotocamera');
});

router.get('/calib', function(req, res, next) {
  fs.readFile('files/calibrazione.json', { encoding: 'utf-8' }, function(err, data) {
    if(err)
      throw err;
    let json = JSON.parse(data);
    res.send(json.fatta);
  });
});

module.exports = router;
