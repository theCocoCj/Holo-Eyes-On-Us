let socket = new WebSocket('ws://localhost:3000');

socket.addEventListener('open', function() {
    socket.send(REQ.CALIBR_FATTA);
});

socket.addEventListener('message', function(evt) {
    let message = evt.data;

    if(message === ANS.CALIBR_FATTA.FALSE) {
        let body = document.getElementsByTagName('body')[0];
        let div = document.getElementById('div-a');
        body.removeChild(div);

        let divMess = document.createElement('div');
        divMess.id = 'div-p';
        body.appendChild(divMess)

        let mess_1 = document.createElement('p');
        mess_1.innerHTML = 'Non ti sei ancora mai calibrato, fallo subito per iniziare a giocare';
        mess_1.className = 'mess';
        divMess.appendChild(mess_1);

        let nSec = 5;
        let meta = document.createElement('meta');
        meta.httpEquiv = 'refresh';
        meta.content = nSec + "; url='calibrazione.html'";
        document.getElementsByTagName('head')[0].appendChild(meta);

        let mess_2 = document.createElement('p');
        mess_2.innerHTML = 'Calibrazione fra ' + nSec;
        mess_2.className = 'mess';
        divMess.appendChild(mess_2);
        setInterval(function() {
            nSec --;
            mess_2.innerHTML = 'Calibrazione fra ' + nSec;
        }, 1000);

    }
    else if(message === ANS.CALIBR_FATTA.TRUE)
        console.log('fatta almeno una volta');
});