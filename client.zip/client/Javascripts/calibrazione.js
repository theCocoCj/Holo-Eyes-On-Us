let inLoading = true;

/*let socket = new WebSocket('ws://localhost:3000');

socket.addEventListener('open', function() {
    socket.send(REQ.ACCENDI_CAM);
});

socket.addEventListener('message', function(evt) {
    let message = evt.data;

    if(message === ANS.ACCENDI_CAM) {
        let body = document.getElementsByTagName('body')[0];
        body.removeChild(body.children[0]);
    }
        console.log('cam accesa')
});*/

window.addEventListener('keypress', function(event) {
    if(event.key === ' ') {
        let body = document.getElementsByTagName('body')[0];
        body.removeChild(body.children[0]);
        inLoading = false;
        //createCanvas(550, 500);

        let angle = document.createElement('div');
        angle.id = 'div-angle';
        body.appendChild(angle);
    } else if(event.key === 't') {
        let n = 0, angle = document.getElementById('div-angle');
        let int = setInterval(() => {
            if(n === 14)
                clearInterval(int);
            else {
                angle.style.backgroundColor = n % 2 === 0? 'rgba(255,255,255,0.65)': '#fff';
                n ++;
            }
        }, 100);
    }
});

function draw() {
    if(!inLoading)
        background('#ff0000');
}