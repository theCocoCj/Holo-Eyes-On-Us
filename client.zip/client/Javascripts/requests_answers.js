const REQ = {
    CALIBR_FATTA: '100',
    ACCENDI_CAM: '101'
};
const ANS = {
    CALIBR_FATTA: {
        FALSE: '200',
        TRUE: '201'
    },
    ACCENDI_CAM: '202'
};